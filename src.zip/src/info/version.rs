
/// This function prints the version.
pub fn print_version(){
  println!("CluE 0.2.2-alpha.1");
}
